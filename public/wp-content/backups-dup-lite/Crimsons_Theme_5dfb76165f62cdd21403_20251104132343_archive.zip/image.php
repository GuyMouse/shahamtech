<?php
    header('Content-Type: image/png');
    readfile('logo.png');
?>